export const prices=[
    {
        _id:0,
        name:'Any',
        array:[0,2000],
    },
    {
        _id:1,
        name:'Rs.0 to Rs.99',
        array:[0,99],
    },
    {
        _id:2,
        name:'Rs.100 to Rs.199',
        array:[100,199],
    },
    {
        _id:3,
        name:'Rs.200 to Rs.499',
        array:[200,499],
    },
    {
        _id:4,
        name:'Rs.500 to Rs.799',
        array:[500,799],
    },
    {
        _id:5,
        name:'Rs.800 to Rs.1000',
        array:[800,1000],
    },
    {
        _id:6,
        name:'More than 1000',
        array:[1001,2000],
    },


];