# goal-keepm
This is a Goal keeper app based on React Native. This app isnt set to deployment, yet designed with complete interface.  Works on Android.

1.Extract the contents inside a folder 'X'.
2.Install an expo cli using CMD globally.
3.Use expo init 'Projectname' command to create a project and select the type 'blank - a minimal...' from the options.
4.Now navigate to the project folder and overwrite the contents with the folder 'X' contents.
5.Use 'npm start' to run the project.
6.Download 'expo go' app in android or ios and install it.
7.Open the app and scan the QR code or enter the URL manually, which can be found in the terminal where you used 'npm start' command.

Note:
I have only completed the tutorial till this and I will update the content when I build and deploy the app in the future.
